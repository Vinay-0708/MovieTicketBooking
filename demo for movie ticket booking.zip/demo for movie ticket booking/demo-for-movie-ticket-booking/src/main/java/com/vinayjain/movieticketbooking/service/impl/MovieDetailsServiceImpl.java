package com.vinayjain.movieticketbooking.service.impl;

import com.vinayjain.movieticketbooking.dto.MovieDto;
import com.vinayjain.movieticketbooking.entity.Moviedetails;
import com.vinayjain.movieticketbooking.mapper.MovieMapper;
import com.vinayjain.movieticketbooking.repository.MovieDetailsRepository;
import com.vinayjain.movieticketbooking.service.MovieDetailsService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovieDetailsServiceImpl implements MovieDetailsService {

    private MovieDetailsRepository movieDetailsRepository;

    public MovieDetailsServiceImpl(MovieDetailsRepository movieDetailsRepository){
        this.movieDetailsRepository=movieDetailsRepository;
    }
    @Override
    public List<MovieDto> findAllMovies() {


        List<Moviedetails> movies= movieDetailsRepository.findAll();
        return movies.stream().map(MovieMapper::mapToMovieDto)
                .collect(Collectors.toList());
    }

    @Override
    public void createMovie(MovieDto movieDto) {
        Moviedetails moviedetails = MovieMapper.mapToMoviedetails(movieDto);
        movieDetailsRepository.save(moviedetails);
    }

    @Override
    public MovieDto findMovieById(Long movieId) {
       Moviedetails moviedetails= movieDetailsRepository.findById(movieId).get();
       return MovieMapper.mapToMovieDto(moviedetails);

    }

    @Override
    public void updateMovie(MovieDto movieDto) {
      Moviedetails moviedetails = MovieMapper.mapToMoviedetails(movieDto);
      movieDetailsRepository.save(moviedetails);
    }

    @Override
    public void deleteMovie(Long movieId) {
        movieDetailsRepository.deleteById(movieId);
    }

    @Override
    public MovieDto findMovieByUrl(String movieUrl) {
        Moviedetails moviedetails = movieDetailsRepository.findByUrl(movieUrl).get();
        return MovieMapper.mapToMovieDto(moviedetails);
    }

    @Override
    public MovieDto findMovieByTitle(String movieTitle) {
       Moviedetails moviedetails=movieDetailsRepository.findByTitle(movieTitle).get();
       return MovieMapper.mapToMovieDto(moviedetails);
    }

}
