package com.vinayjain.movieticketbooking.service;

import com.vinayjain.movieticketbooking.dto.RegistrationDto;
import com.vinayjain.movieticketbooking.entity.User;

public interface UserService {
    void saveUser(RegistrationDto registrationDto);

    User findByEmail(String email);
}
