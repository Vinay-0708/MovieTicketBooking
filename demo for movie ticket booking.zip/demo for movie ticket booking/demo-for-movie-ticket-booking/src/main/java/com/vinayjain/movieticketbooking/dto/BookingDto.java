package com.vinayjain.movieticketbooking.dto;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingDto {
    private Long id;
    private String name;
    private String email;
    private Long contact_no;
    private Long seats;
}
