package com.vinayjain.movieticketbooking.mapper;

import com.vinayjain.movieticketbooking.dto.MovieDto;
import com.vinayjain.movieticketbooking.entity.Moviedetails;

public class MovieMapper {
    public static MovieDto mapToMovieDto(Moviedetails moviedetails){
       return MovieDto.builder()
               .id(moviedetails.getId())
               .title(moviedetails.getTitle())
               .url(moviedetails.getUrl())
               .movieGenere(moviedetails.getMovieGenere())
               .shortDescription(moviedetails.getShortDescription())
              //.image(moviedetails.getImage())
               .address(moviedetails.getAddress())
               .build();

    }

    // map Postdto to Post entity
    public static Moviedetails mapToMoviedetails(MovieDto movieDto){
        return Moviedetails.builder()
                .id(movieDto.getId())
                .title(movieDto.getTitle())
                .movieGenere(movieDto.getMovieGenere())
                .url(movieDto.getUrl())
                .shortDescription(movieDto.getShortDescription())
                //.image(movieDto.getImage())
                .address(movieDto.getAddress())
                .build();
    }
}
