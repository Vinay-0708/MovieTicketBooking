package com.vinayjain.movieticketbooking.mapper;

import com.vinayjain.movieticketbooking.dto.BookingDto;
import com.vinayjain.movieticketbooking.entity.Booking;

public class BookingMapper {

    public static BookingDto mapToBookingDto(Booking booking){
        return BookingDto.builder()
                .id(booking.getId())
                .name(booking.getName())
                .email(booking.getEmail())
                .contact_no(booking.getContact_no())
                .seats(booking.getSeats())
                .build();

    }

    public static Booking mapToBooking(BookingDto bookingDto){
        return Booking.builder()
                .id(bookingDto.getId())
                .name(bookingDto.getName())
                .email(bookingDto.getEmail())
                .contact_no(bookingDto.getContact_no())
                .seats(bookingDto.getSeats())
                .build();
    }
}
