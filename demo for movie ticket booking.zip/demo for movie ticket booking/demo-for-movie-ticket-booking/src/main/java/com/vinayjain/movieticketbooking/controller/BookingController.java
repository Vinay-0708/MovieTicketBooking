package com.vinayjain.movieticketbooking.controller;

import com.vinayjain.movieticketbooking.dto.BookingDto;
import com.vinayjain.movieticketbooking.service.BookingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BookingController {
    private BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/BookUser/save")
    public String createBooking(Model model){


       return "blog/Checkout_page";

    }
}
