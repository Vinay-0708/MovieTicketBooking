package com.vinayjain.movieticketbooking.service;

import com.vinayjain.movieticketbooking.dto.BookingDto;

public interface BookingService {

    void createBooking(Long id, BookingDto bookingDto);
}
