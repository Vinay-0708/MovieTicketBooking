package com.vinayjain.movieticketbooking.service;

import com.vinayjain.movieticketbooking.dto.MovieDto;

import java.util.List;

public interface MovieDetailsService {

    List<MovieDto> findAllMovies();

    void createMovie(MovieDto movieDto);
    MovieDto findMovieById(Long movieId);
    void updateMovie(MovieDto movieDto);

    void deleteMovie(Long movieId);

   MovieDto findMovieByUrl(String movieUrl);

    MovieDto findMovieByTitle(String movieTitle);
}
