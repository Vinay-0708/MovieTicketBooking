package com.vinayjain.movieticketbooking.controller;

import com.vinayjain.movieticketbooking.dto.MovieDto;
import com.vinayjain.movieticketbooking.entity.Moviedetails;
import com.vinayjain.movieticketbooking.service.MovieDetailsService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class MoviedetailsController {

    private MovieDetailsService movieDetailsService;

    public MoviedetailsController(MovieDetailsService movieDetailsService){
      this.movieDetailsService=movieDetailsService;
    }
    @GetMapping("/admin/movies")
    public String movies(Model model){
        List<MovieDto> movies= movieDetailsService.findAllMovies();
        model.addAttribute("movies",movies);
        return "/admin/movies";
    }
    @GetMapping("/admin/movies/newmovie")
    public String newMovieForm(Model model){
        MovieDto movieDto = new MovieDto();
        model.addAttribute("movie",movieDto);
        return "admin/create_movie";
    }

    @GetMapping("/admin/movies/{movieId}/edit")
    public String editMovieForm(@PathVariable("movieId") Long movieId,
                                Model model){
       MovieDto movieDto= movieDetailsService.findMovieById(movieId);
       model.addAttribute("movie",movieDto);
       return "admin/edit_movie";
    }
@PostMapping("/admin/movies/{movieId}")
    public String updateMovie(@PathVariable("movieId") Long movieId,
                              @Valid @ModelAttribute("movie") MovieDto movie,
                              BindingResult result,
                              Model model){
        if(result.hasErrors()){
            model.addAttribute("movie", movie);
            return "admin/edit_movie";
        }
        movie.setId(movieId);
        movieDetailsService.updateMovie(movie);
        return "redirect:/admin/movies";

    }
  @GetMapping("admin/movies/{movieId}/delete")
  public String deleteMovie(@PathVariable("movieId") Long movieId){
        movieDetailsService.deleteMovie(movieId);
        return "redirect:/admin/movies";
    }
    @PostMapping("/admin/movies")
    public String createMovie(@Valid @ModelAttribute("movie") MovieDto movieDto,
                              BindingResult result, Model model){
        if(result.hasErrors()){
            model.addAttribute("movie",movieDto);
            return "admin/create_movie";
        }
        movieDetailsService.createMovie(movieDto);
        return "redirect:/admin/movies";
    }

//    @GetMapping("/admin/movies/{movieTitle}/view")
//    public String viewMovie(@PathVariable("movieTitle") String movieTitle, Model model){
//        MovieDto movieDto = movieDetailsService.findMovieByTitle(movieTitle);
//        model.addAttribute("movie",movieDto);
//        return "admin/view_movie";
//    }
    private static String getUrl(String movieTitle){
        // OOPS Concepts Explained in Java
        // oops-concepts-explained-in-java
        String title = movieTitle.trim().toLowerCase();
        String url = title.replaceAll("\\s+", "-");
        url = url.replaceAll("[^A-Za-z0-9]", "-");
        return url;
    }
}
